// Small enhancement: smooth scroll for in-page CTA (works if anchor exists on page)
document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
});

const nav = document.getElementById('pageSubnav');
nav.addEventListener('click', (e) => {
    const a = e.target.closest('a');
    if (!a) return;
    // prevent page jump if you prefer smooth scroll; remove if default anchor behavior desired
    e.preventDefault();

    // toggle active
    nav.querySelectorAll('a').forEach(x => x.classList.remove('active'));
    a.classList.add('active');

    // optional: smooth scroll to section id if exists
    const id = a.dataset.target || a.getAttribute('href').replace('#', '');
    const el = document.getElementById(id);
    if (el) {
        const topOffset = 0; // set to main nav height if needed
        const top = el.getBoundingClientRect().top + window.scrollY - topOffset - 8;
        window.scrollTo({ top, behavior: 'smooth' });
    }
});

// main nav

(function () {
    const nav = document.getElementById('mainNav');
    if (!nav) return;

    const indicator = document.getElementById('navIndicator');
    const items = [...nav.querySelectorAll('.nav-item, .nav-item, .nav-item')]; // fallback: we'll get links below
    // better: select anchors inside nav (excluding indicator span)
    const links = Array.from(nav.querySelectorAll('a:not(#navIndicator)'));

    // set CSS for nav to position relative (ensures indicator alignment)
    nav.style.position = 'relative';

    // helper to move indicator to given element with optional width padding
    function placeIndicator(el, animate = true) {
        if (!el) {
            indicator.style.width = '0px';
            return;
        }
        const navRect = nav.getBoundingClientRect();
        const elRect = el.getBoundingClientRect();
        const left = Math.round(elRect.left - navRect.left);
        const width = Math.round(elRect.width);
        if (!animate) indicator.style.transition = 'none';
        indicator.style.transform = `translateX(${left}px)`;
        indicator.style.width = `${width}px`;
        // restore transition (small timeout to allow instant change)
        if (!animate) {
            requestAnimationFrame(() => {
                indicator.style.transition = '';
            });
        }
    }

    // initialize: pick first link as active (or link with .active)
    let activeLink = links.find(l => l.classList.contains('active')) || links[0];
    if (activeLink) activeLink.classList.add('active');
    // ensure indicator uses transform instead of left to keep it GPU-accelerated
    indicator.style.left = '0px';
    indicator.style.transition = 'transform 260ms cubic-bezier(.2,.9,.2,1), width 260ms cubic-bezier(.2,.9,.2,1)';

    // place on load
    function refreshIndicator(initial = false) {
        if (!activeLink) {
            placeIndicator(null);
            return;
        }
        placeIndicator(activeLink, !initial);
    }
    window.addEventListener('load', () => refreshIndicator(true));
    window.addEventListener('resize', () => refreshIndicator(true));

    // hover preview: move indicator to hovered item but don't set active
    links.forEach(link => {
        link.addEventListener('mouseenter', (e) => {
            placeIndicator(link);
        });
        link.addEventListener('mouseleave', (e) => {
            placeIndicator(activeLink || null);
        });

        // click => set as active, smooth scroll if target exists
        link.addEventListener('click', (e) => {
            // if it's an in-page anchor, do smooth scroll and prevent default immediate jump
            const href = link.getAttribute('href') || '';
            const isHash = href.startsWith('#') && href.length > 1;
            if (isHash) {
                e.preventDefault();
                const targetId = href.slice(1);
                const targetEl = document.getElementById(targetId);
                // compute top offset for sticky header
                const header = document.querySelector('header.sticky') || document.querySelector('header');
                const headerHeight = header ? header.getBoundingClientRect().height : 0;
                if (targetEl) {
                    const top = targetEl.getBoundingClientRect().top + window.scrollY - headerHeight - 8;
                    window.scrollTo({ top, behavior: 'smooth' });
                }
            }

            // update active styling
            links.forEach(l => l.classList.remove('active'));
            link.classList.add('active');
            activeLink = link;
            placeIndicator(activeLink);
        });

        // keyboard: allow Enter/Space to activate like click
        link.addEventListener('keydown', (ev) => {
            if (ev.key === 'Enter' || ev.key === ' ') {
                ev.preventDefault();
                link.click();
            }
        });
    });

    // when page scrolls, optionally auto-update active based on section in view
    const sections = Array.from(document.querySelectorAll('main section[id]'));
    if (sections.length) {
        const io = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const id = entry.target.id;
                    const link = links.find(l => (l.getAttribute('href') || '') === '#' + id);
                    if (link) {
                        links.forEach(l => l.classList.remove('active'));
                        link.classList.add('active');
                        activeLink = link;
                        placeIndicator(activeLink);
                    }
                }
            });
        }, { root: null, threshold: 0.45 });
        sections.forEach(s => io.observe(s));
    }

    // MOBILE MENU: simple toggle
    const mobileToggle = document.getElementById('mobileToggle');
    const mobileMenu = document.getElementById('mobileMenu');
    const mobileQuote = document.getElementById('mobileQuote');
    if (mobileToggle && mobileMenu) {
        mobileToggle.addEventListener('click', () => {
            const open = !mobileMenu.classList.contains('hidden');
            if (open) {
                mobileMenu.classList.add('hidden');
                mobileMenu.classList.remove('block');
                mobileToggle.setAttribute('aria-expanded', 'false');
            } else {
                mobileMenu.classList.remove('hidden');
                mobileMenu.classList.add('block');
                mobileToggle.setAttribute('aria-expanded', 'true');
            }
        });
    }
})();

// Enterprise-level details (audit ready). Edit copy as needed.
const PROCESS_DETAILS = {
    yarn: {
        title: 'Yarn — Procurement & Traceability',
        body: `<p><strong>What we track:</strong> Supplier certificates, lot CoA, fibre composition, and full-chain traceability per SKU.</p>
               <p><strong>KPI examples:</strong> Incoming quality acceptance rate, supplier lead-time variance, lot retention records.</p>
               <p><strong>Systems:</strong> PLM/ERP integration, QR-coded lot tags and digital CoA archive for audits.</p>`
    },
    winding: {
        title: 'Winding — Precision Preparation',
        body: `<p><strong>Key controls:</strong> Tension profiling, automated defect removal, and spool-level identifiers for process mapping.</p>
               <p><strong>Value:</strong> Reduces knitting stoppages and yarn-related rejects by ensuring consistent feed.</p>`
    },
    slitting: {
        title: 'Slitting — Width & Feed Consistency',
        body: `<p><strong>Controls:</strong> Width tolerance monitoring, blade QC, and inline inspection to prevent feed irregularities downstream.</p>`
    },
    knitting: {
        title: 'Knitting — Production & Sampling',
        body: `<p><strong>Features:</strong> Modern machine fleet, in-line parameter logging, sample approval gates, and SPC alerts for anomalies.</p>`
    },
    dyeing: {
        title: 'Dyeing — Colour & Chemical Management',
        body: `<p><strong>Process:</strong> Lab-dip approval, recipe-controlled systems, chemical dosing, wastewater monitoring and OEKO compliant handling.</p>`
    },
    compacting: {
        title: 'Compacting — Dimensional Stability',
        body: `<p><strong>Outcome:</strong> Consistent shrinkage control, KPI logging, and certification-ready reports for fit validation.</p>`
    },
    finishing: {
        title: 'Finishing — Quality Enforcement',
        body: `<p><strong>Checks:</strong> Multi-point inspection, defect classification, and corrective action logs to maintain low defect-per-million metrics.</p>`
    },
    packing: {
        title: 'Packing — Traceable Dispatch',
        body: `<p><strong>Includes:</strong> Batch labeling, carton-level QR codes, packing lists, and export documentation integrated with logistics partners.</p>`
    }
};

// Fill modal with appropriate content when link/button clicked
document.addEventListener('click', function (e) {
    const target = e.target.closest('[data-step]') || e.target.closest('[data-step-card]');
    if (!target) return;

    // prefer data-step attribute (stepper & "see more" links have data-step)
    const step = target.getAttribute('data-step') || target.getAttribute('data-step-card');
    if (!step) return;

    const data = PROCESS_DETAILS[step];
    if (!data) return;

    const modalTitle = document.getElementById('procModalLabel');
    const modalBody = document.getElementById('procModalBody');
    modalTitle.innerText = data.title;
    modalBody.innerHTML = data.body;
});

// Keyboard accessibility: allow Enter to activate step
document.querySelectorAll('.step').forEach(el => {
    el.addEventListener('keydown', function (ev) {
        if (ev.key === 'Enter' || ev.key === ' ') {
            ev.preventDefault();
            // trigger modal same as click on 'see-more' for that step
            const step = this.getAttribute('data-step');
            const correspondingLink = document.querySelector('[data-step="' + step + '"] a[data-bs-toggle="modal"]');
            if (correspondingLink) correspondingLink.click();
        }
    });
});



// process over view 
(function () {
    // ---------- phase definitions ----------
    const PHASES = [
        {
            id: 'yarn', label: 'Yarn', short: 'Procurement & Traceability', icon: 'fa-industry',
            intro: 'Supplier qualification, lab testing and SKU-level traceability to ensure provenance and consistency for export markets.',
            bullets: [
                'Supplier CoA, fibre composition and lot-level trace logs.',
                'Incoming QC: tensile, micronaire, and contamination screening.',
                'PLM/ERP lot tagging for full-chain traceability and recall readiness.'
            ],
            kpis: [{ num: '99.2%', lbl: 'IQC Acceptance' }, { num: '24–48h', lbl: 'Lot Release' }]
        },
        {
            id: 'winding', label: 'Winding', short: 'Tension & Spool Prep', icon: 'fa-cogs',
            intro: 'Automated winding with tension profiling and spool tagging to minimize downstream defects.',
            bullets: [
                'Tension-controlled automated winders with inline defect removal.',
                'Spool QR-tags for machine-to-batch mapping and analytics.',
                'Reduces knitting stoppages and improves line efficiency.'
            ],
            kpis: [{ num: '>98%', lbl: 'Feed Consistency' }, { num: '0.6%', lbl: 'Defect Rate' }]
        },
        {
            id: 'slitting', label: 'Slitting', short: 'Width Control', icon: 'fa-ruler-horizontal',
            intro: 'Precision slitting ensures uniform width and consistent feed to the knitting floor.',
            bullets: [
                'Blade QC, inline width measurement and corrective trimming.',
                'Adaptive tension to prevent edge fraying and feed irregularities.',
                'Integrates with MES for feed traceability.'
            ],
            kpis: [{ num: '±1mm', lbl: 'Width Tolerance' }, { num: '99.5%', lbl: 'Feed Accuracy' }]
        },
        {
            id: 'knitting', label: 'Knitting', short: 'Gauge & Sampling', icon: 'fa-industry',
            intro: 'Modern machine fleet, SPC monitoring and sample approval gates for consistent fabric quality.',
            bullets: [
                'Circular & flat-bed machines with automated parameter logging.',
                'First-sample approval workflows and SPC alerts on deviations.',
                'Real-time dashboards to track machine OEE.'
            ],
            kpis: [{ num: 'OEE 82%', lbl: 'Typical OEE' }, { num: '2.1%', lbl: 'Fabric Defect PPM' }]
        },
        {
            id: 'dyeing', label: 'Dyeing', short: 'Colour & Chemical Mgmt', icon: 'fa-droplet',
            intro: 'Recipe-controlled colour systems, chemical dosing and effluent management aligned to OEKO standards.',
            bullets: [
                'Lab-dip approval and batch recipe locking to prevent shade drift.',
                'Automated dosing, chemical logs and wastewater monitoring.',
                'OEKO & wastewater compliance-ready processes.'
            ],
            kpis: [{ num: 'ΔE < 1.5', lbl: 'Shade Variance' }, { num: '<0.5%', lbl: 'Re-dye Rate' }]
        },
        {
            id: 'compacting', label: 'Compacting', short: 'Dimensional Stability', icon: 'fa-arrows-up-down',
            intro: 'Controlled compacting lines and KPI logging to guarantee shrinkage control and first-pass fit.',
            bullets: [
                'Calibrated compactors with size-range profiles.',
                'Shrinkage logging and certification-ready reports.',
                'Inline testing to validate size stability across batches.'
            ],
            kpis: [{ num: '±1%', lbl: 'Shrinkage Var.' }, { num: 'Pass', lbl: 'Fit First-Pass' }]
        },
        {
            id: 'finishing', label: 'Finishing', short: 'Quality Enforcement', icon: 'fa-check-double',
            intro: 'Multi-point QC, defect classification and corrective-action logs to maintain low PPM metrics.',
            bullets: [
                'Multi-stage visual & digital inspection with root-cause tracking.',
                'Trimming, pressing and final QA sign-off checkpoints.',
                'Corrective action & non-conformance records for continuous improvement.'
            ],
            kpis: [{ num: 'PPM < 200', lbl: 'Final Defect PPM' }, { num: '95%', lbl: 'On-Time QA' }]
        },
        {
            id: 'packing', label: 'Packing', short: 'Traceable Dispatch', icon: 'fa-boxes-stacked',
            intro: 'Batch labelling, carton-level QR codes and export documentation integrated with logistics partners.',
            bullets: [
                'Cartonization with QR/Barcodes for full shipment traceability.',
                'Export-ready packing lists, ASN and logistics integration.',
                'GPS-enabled dispatch scheduling and visibility for clients.'
            ],
            kpis: [{ num: '99.8%', lbl: 'Shipment Accuracy' }, { num: 'T+1', lbl: 'Dispatch SLA' }]
        }
    ];

    // DOM refs
    const stepsList = document.getElementById('stepsList');
    const detailContent = document.getElementById('detailContent');
    const phaseTitle = document.getElementById('phaseTitle');
    const phaseIntro = document.getElementById('phaseIntro');
    const phaseShort = document.getElementById('phaseShort');
    const phaseBullets = document.getElementById('phaseBullets');
    const kpiRow = document.getElementById('kpiRow');
    const phaseIcon = document.getElementById('phaseIcon');
    const btnRequest = document.getElementById('btnRequest');

    let selectedIndex = 0;
    let animating = false;

    // build left list
    function buildSteps() {
        stepsList.innerHTML = '';
        PHASES.forEach((p, idx) => {
            const li = document.createElement('li');
            li.className = 'mb-2';
            li.innerHTML = `
            <div class="step-item" role="option" tabindex="0" data-idx="${idx}" aria-selected="${idx === 0}">
              <div class="step-badge">${idx + 1}</div>
              <div class="step-meta">
                <div class="step-name">${p.label}</div>
                <div class="step-desc">${p.short}</div>
              </div>
            </div>
          `;
            stepsList.appendChild(li);

            const item = li.querySelector('.step-item');
            item.addEventListener('click', () => changeTo(idx));
            item.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); changeTo(idx); }
                if (e.key === 'ArrowDown') { e.preventDefault(); focusStep(Math.min(idx + 1, PHASES.length - 1)); }
                if (e.key === 'ArrowUp') { e.preventDefault(); focusStep(Math.max(0, idx - 1)); }
            });
        });
        updateActive();
    }

    function focusStep(i) {
        const node = stepsList.querySelector('[data-idx="' + i + '"]');
        if (node) node.focus();
    }

    // update left active styles
    function updateActive() {
        stepsList.querySelectorAll('.step-item').forEach(el => {
            const idx = Number(el.dataset.idx);
            if (idx === selectedIndex) { el.classList.add('active'); el.setAttribute('aria-selected', 'true'); }
            else { el.classList.remove('active'); el.setAttribute('aria-selected', 'false'); }
        });
    }

    // render details into right panel
    function renderDetail(idx) {
        const p = PHASES[idx];
        phaseTitle.textContent = p.label + ' — ' + p.short;
        phaseIntro.textContent = p.intro;
        phaseShort.textContent = p.label;
        phaseIcon.className = 'fa ' + (p.icon || 'fa-industry');

        // bullets
        phaseBullets.innerHTML = '';
        p.bullets.forEach(b => {
            const li = document.createElement('li'); li.textContent = b;
            phaseBullets.appendChild(li);
        });

        // kpis
        kpiRow.innerHTML = '';
        (p.kpis || []).forEach(k => {
            const card = document.createElement('div'); card.className = 'kpi';
            card.innerHTML = `<div class="num">${k.num}</div><div class="lbl">${k.lbl}</div>`;
            kpiRow.appendChild(card);
        });

        // mailto with subject
        btnRequest.href = `mailto:enterprise@primagarments.com?subject=Request%20SOP%20-%20${encodeURIComponent(p.label)}`;
    }

    // smooth swap animation: exit then enter
    function animateSwap(newIndex) {
        if (animating || newIndex === selectedIndex) return;
        animating = true;
        const old = detailContent;
        // add exit classes
        old.classList.remove('content-enter', 'content-enter-active');
        old.classList.add('content-exit');
        requestAnimationFrame(() => {
            old.classList.add('content-exit-active');
        });

        // after exit duration, swap content and enter
        setTimeout(() => {
            // update index & content
            selectedIndex = newIndex;
            renderDetail(selectedIndex);
            updateActive();

            // swap classes for enter animation (reflow)
            old.classList.remove('content-exit', 'content-exit-active');
            old.classList.add('content-enter');
            requestAnimationFrame(() => {
                old.classList.add('content-enter-active');
                // remove enter classes after animation completes
                setTimeout(() => {
                    old.classList.remove('content-enter', 'content-enter-active');
                    animating = false;
                }, 420); // slight buffer
            });
        }, 280); // exit duration matches CSS transition
    }

    // immediate change (no animation) - used at init
    function changeTo(idx) {
        if (animating) return;
        if (idx === selectedIndex) return;
        animateSwap(idx);
    }

    // next/prev control
    function next() {
        const n = (selectedIndex + 1) % PHASES.length;
        animateSwap(n);
        focusStep(n);
    }
    function prev() {
        const p = (selectedIndex - 1 + PHASES.length) % PHASES.length;
        animateSwap(p);
        focusStep(p);
    }

    // keyboard nav (global)
    window.addEventListener('keydown', (e) => {
        if (['INPUT', 'TEXTAREA', 'SELECT', 'BUTTON'].includes(document.activeElement.tagName)) return;
        if (e.key === 'ArrowRight') next();
        if (e.key === 'ArrowLeft') prev();
        if (e.key >= '1' && e.key <= String(PHASES.length)) {
            const idx = Number(e.key) - 1;
            animateSwap(idx);
            focusStep(idx);
        }
    });

    // wire next/prev buttons
    document.getElementById('nextStep').addEventListener('click', next);
    document.getElementById('prevStep').addEventListener('click', prev);

    // initialize
    buildSteps();
    // initial render without heavy animation
    renderDetail(selectedIndex);

    // expose for debug
    window.ProcessUI = { next, prev, changeTo };
})();



// -------------- INfra

(function () {
    // ---------- Data (replace with your actual assets & copy) ----------
    const gallery = [
        { src: '/assets/factory-1.jpg', alt: 'Factory exterior with logistics bay' },
        { src: '/assets/knitting-floor.jpg', alt: 'Knitting floor with modern machines' },
        { src: '/assets/dyeing-unit.jpg', alt: 'High-efficiency dyeing plant' },
        { src: '/assets/packing-line.jpg', alt: 'Automated packing line' }
    ];

    const capabilities = [
        { icon: 'fa-cut', title: 'Automated Cutting', short: 'CNC cutting for accuracy & yield', details: ['CNC CAM nesting to reduce waste', 'Vision-assisted knife control', 'Capacity: 6 simultaneous lines'], foot: '6 cutting lines' },
        { icon: 'fa-tint', title: 'High-Efficiency Dyeing', short: 'Recipe-controlled, closed-loop', details: ['Automated dosing & lab-dip control', 'Effluent treatment & monitoring', 'OEKO & discharge compliance'], foot: 'Batch size: up to 2T' },
        { icon: 'fa-microchip', title: 'Inline Digital QC', short: 'Computer vision reduces escapes', details: ['AI-driven defect classification', 'Digital QC records & dashboards', 'Integration with MES/ERP'], foot: 'Defect PPM < 250' },
        { icon: 'fa-boxes-stacked', title: 'Automated Packing', short: 'Cartonization & barcode labelling', details: ['ASN generation & palletizing', 'Carton QR for traceability', 'Logistics system integration'], foot: '3k cartons/day' }
    ];

    const certs = [
        { id: 'iso9001', name: 'ISO 9001', img: '/assets/cert-iso.svg' },
        { id: 'oeko', name: 'OEKO-TEX', img: '/assets/cert-oeko.svg' },
        { id: 'smeta', name: 'SMETA', img: '/assets/cert-smeta.svg' }
    ];

    // ---------- DOM refs ----------
    const galleryImg = document.getElementById('galleryImg');
    const thumbs = document.getElementById('thumbs');
    const galleryMain = document.getElementById('galleryMain');
    const galleryOpen = document.getElementById('galleryOpen');
    const galleryModalImg = document.getElementById('galleryModalImg');

    const capGrid = document.getElementById('capGrid');
    const certRow = document.getElementById('certRow');

    // ---------- Gallery build ----------
    let currentIdx = 0;
    let autoplay = true;
    let autoplayTimer;

    function setGalleryIndex(i, noAutoplayReset) {
        currentIdx = i % gallery.length;
        if (currentIdx < 0) currentIdx += gallery.length;
        const g = gallery[currentIdx];
        galleryImg.src = g.src;
        galleryImg.alt = g.alt;
        galleryModalImg.src = g.src;
        // active thumbnail highlight
        document.querySelectorAll('.thumb').forEach((t, idx) => t.classList.toggle('active', idx === currentIdx));
        // reset autoplay if not suppressed
        if (!noAutoplayReset) restartAutoplay();
    }

    function buildThumbs() {
        thumbs.innerHTML = '';
        gallery.forEach((g, idx) => {
            const d = document.createElement('div');
            d.className = 'thumb';
            d.innerHTML = `<img src="${g.src}" alt="${g.alt}" loading="lazy">`;
            d.setAttribute('role', 'tab');
            d.setAttribute('aria-selected', 'false');
            d.addEventListener('click', () => setGalleryIndex(idx));
            thumbs.appendChild(d);
        });
    }

    function restartAutoplay() {
        clearInterval(autoplayTimer);
        if (!autoplay) return;
        autoplayTimer = setInterval(() => {
            setGalleryIndex(currentIdx + 1, true);
        }, 4200);
    }

    // pause on hover
    galleryMain.addEventListener('mouseenter', () => { autoplay = false; clearInterval(autoplayTimer); });
    galleryMain.addEventListener('mouseleave', () => { autoplay = true; restartAutoplay(); });

    // open fullscreen
    galleryOpen.addEventListener('click', () => {
        const modal = new bootstrap.Modal(document.getElementById('galleryModal'));
        document.getElementById('galleryModalImg').src = gallery[currentIdx].src;
        modal.show();
    });

    // ---------- Capabilities build ----------
    function buildCapabilities() {
        capGrid.innerHTML = '';
        capabilities.forEach((c, idx) => {
            const el = document.createElement('div');
            el.className = 'cap';
            el.setAttribute('tabindex', '0');
            el.innerHTML = `
        <div class="cap-head">
          <div class="icon"><i class="fa ${c.icon}"></i></div>
          <div>
            <div class="cap-title">${c.title}</div>
            <div class="cap-small">${c.short}</div>
          </div>
        </div>
        <div class="cap-details">
          <ul style="margin-top:8px; padding-left:18px;">
            ${c.details.map(d => `<li>${d}</li>`).join('')}
          </ul>
          <div class="text-end small text-muted">${c.foot}</div>
        </div>
      `;
            // toggle open on click or Enter
            el.addEventListener('click', (e) => {
                el.classList.toggle('open');
            });
            el.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); el.classList.toggle('open'); }
            });
            capGrid.appendChild(el);
        });
    }

    // ---------- Certs build ----------
    function buildCerts() {
        certRow.innerHTML = '';
        certs.forEach(c => {
            const el = document.createElement('div');
            el.className = 'cert';
            el.setAttribute('role', 'button');
            el.innerHTML = `<img src="${c.img}" alt="${c.name}" style="max-height:36px; width:auto;">`;
            el.addEventListener('click', () => {
                document.getElementById('certTitle').textContent = c.name;
                document.getElementById('certImg').src = c.img;
                new bootstrap.Modal(document.getElementById('certModal')).show();
            });
            certRow.appendChild(el);
        });
    }

    // ---------- Stats count when visible ----------
    function animateCounters() {
        document.querySelectorAll('.stat .num').forEach(el => {
            const target = Number(el.dataset.target || el.textContent.replace(/[^\d]/g, '')) || 0;
            if (el._animated) return;
            const start = 0;
            const dur = 1200;
            let startTime = null;
            function step(ts) {
                if (!startTime) startTime = ts;
                const progress = Math.min((ts - startTime) / dur, 1);
                const val = Math.floor(progress * target);
                el.textContent = (target >= 1000) ? (Math.floor(val)).toLocaleString() : val;
                if (progress < 1) requestAnimationFrame(step);
                else el._animated = true;
            }
            requestAnimationFrame(step);
        });
    }

    // observe when stats area enters viewport
    const statsEl = document.querySelector('.stats');
    if ('IntersectionObserver' in window && statsEl) {
        const io = new IntersectionObserver(entries => {
            entries.forEach(ent => { if (ent.isIntersecting) { animateCounters(); io.disconnect(); } });
        }, { threshold: 0.35 });
        io.observe(statsEl);
    } else {
        // fallback
        animateCounters();
    }

    // ---------- init ----------
    buildThumbs();
    setGalleryIndex(0);
    restartAutoplay();

    buildCapabilities();
    buildCerts();

    // keyboard navigation: left/right for gallery (if focused)
    galleryMain.addEventListener('keydown', function (e) {
        if (e.key === 'ArrowRight') setGalleryIndex(currentIdx + 1);
        if (e.key === 'ArrowLeft') setGalleryIndex(currentIdx - 1);
    });

    // Accessible: thumbs keyboard nav
    thumbs.addEventListener('keydown', (e) => {
        const t = e.target.closest('.thumb');
        if (!t) return;
        let idx = Array.from(thumbs.children).indexOf(t);
        if (e.key === 'ArrowRight') { e.preventDefault(); setGalleryIndex(idx + 1); thumbs.children[(idx + 1) % thumbs.children.length].focus(); }
        if (e.key === 'ArrowLeft') { e.preventDefault(); setGalleryIndex(idx - 1); thumbs.children[(idx - 1 + thumbs.children.length) % thumbs.children.length].focus(); }
    });

    // lazy load gallery images (if images large)
    document.querySelectorAll('.gallery img, .thumb img').forEach(img => {
        if (img.complete) return;
        img.addEventListener('error', () => { img.style.background = '#ddd'; });
    });

    // end IIFE
})();



// products 

const products = [
    { title: 'Premium Cotton', desc: 'Soft, durable cotton for global apparel', img: '/assets/product1.jpg' },
    { title: 'Eco Denim', desc: 'Sustainable denim with OEKO-TEX certification', img: '/assets/product2.jpg' },
    { title: 'Technical Knit', desc: 'Moisture-wicking, performance fabrics', img: '/assets/product3.jpg' },
    { title: 'Linen Collection', desc: 'Breathable, lightweight luxury fabrics', img: '/assets/product4.jpg' }
];

const carousel = document.getElementById('productCarousel');
products.forEach(p => {
    const card = document.createElement('div');
    card.className = 'product-card';
    card.innerHTML = `
      <img src="${p.img}" alt="${p.title}">
      <div class="product-card-body">
        <div class="product-card-title">${p.title}</div>
        <div class="product-card-desc">${p.desc}</div>
      </div>
    `;
    carousel.appendChild(card);
});

// client logo session

const clients = [
    { name: 'Brand A', img: '/assets/brand1.svg' },
    { name: 'Brand B', img: '/assets/brand2.svg' },
    { name: 'Brand C', img: '/assets/brand3.svg' },
    { name: 'Brand D', img: '/assets/brand4.svg' }
];
const testimonials = [
    { text: 'PrimaGarments delivers exceptional quality and on-time shipments, every time.', author: 'Sourcing Manager, Brand A' },
    { text: 'Their sustainable fabrics and traceable supply chain make us confident in our compliance.', author: 'Head of Procurement, Brand B' }
];

const clientsCarousel = document.getElementById('clientsCarousel');
clients.forEach(c => {
    const el = document.createElement('div');
    el.className = 'client-logo';
    el.innerHTML = `<img src="${c.img}" alt="${c.name}" style="max-height:48px;">`;
    clientsCarousel.appendChild(el);
});

const testimonialsEl = document.getElementById('testimonials');
testimonials.forEach(t => {
    const card = document.createElement('div');
    card.className = 'testimonial-card';
    card.innerHTML = `<div class="testimonial-text">"${t.text}"</div><div class="testimonial-author">- ${t.author}</div>`;
    testimonialsEl.appendChild(card);
});






document.getElementById('inquiryForm').addEventListener('submit', function (e) {
    e.preventDefault();
    alert('Thank you! Your inquiry has been submitted. We will contact you shortly.');
    this.reset();
});